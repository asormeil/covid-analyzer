module.exports = {
  transform: {
    "^.+\\.jsx?$": "babel-jest",
  },
};
